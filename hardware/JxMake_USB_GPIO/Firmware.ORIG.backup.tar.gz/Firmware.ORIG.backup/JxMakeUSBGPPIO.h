/*
 * Copyright (C) 2022-2026 Aloysius Indrayanto
 *
 * This file is part of the JxMake program, see LICENSE file for the license details.
 */

/*
             LUFA Library
     Copyright (C) Dean Camera, 2021.

  dean [at] fourwalledcubicle [dot] com
           www.lufa-lib.org
*/

/*
  Copyright 2021  Dean Camera (dean [at] fourwalledcubicle [dot] com)

  Permission to use, copy, modify, distribute, and sell this
  software and its documentation for any purpose is hereby granted
  without fee, provided that the above copyright notice appear in
  all copies and that both that the copyright notice and this
  permission notice and warranty disclaimer appear in supporting
  documentation, and that the name of the author not be used in
  advertising or publicity pertaining to distribution of the
  software without specific, written prior permission.

  The author disclaims all warranties with regard to this
  software, including all implied warranties of merchantability
  and fitness.  In no event shall the author be liable for any
  special, indirect or consequential damages or any damages
  whatsoever resulting from loss of use, data or profits, whether
  in an action of contract, negligence or other tortious action,
  arising out of or in connection with the use or performance of
  this software.
*/


#ifndef __JXMAKE_USB_GPIO_H__
#define __JXMAKE_USB_GPIO_H__

	/* Includes: */
		#include <stdint.h>

		#include <avr/interrupt.h>
		#include <avr/io.h>
		#include <avr/pgmspace.h>
		#include <avr/power.h>
		#include <avr/wdt.h>
		#include <util/atomic.h>

		#include <LUFA/Drivers/Board/Board.h>
		#include <LUFA/Drivers/Board/LEDs.h>
		#include <LUFA/Drivers/Misc/RingBuffer.h>
		#include <LUFA/Drivers/USB/USB.h>
		#include <LUFA/Platform/Platform.h>

		#include "ActivityLED.h"
		#include "Descriptors.h"
		#include "Millis.h"
		#include "Utils.h"
		#include "Modules/HW_GPIO.h"
		#include "Modules/BB_USRT.h"
		#include "Modules/HW_UART_USRT.h"
		#include "Modules/HW_SPI.h"
		#include "Modules/HW_TWI.h"
		#include "Protocol/HandlerPrimary.h"
		#include "Protocol/HandlerSecondary.h"

	/* Macros: */
		/** LED mask for the library LED driver, to indicate that the USB interface is not ready. */
		#define LEDMASK_USB_NOTREADY     LEDS_LED1

		/** LED mask for the library LED driver, to indicate that the USB interface is enumerating. */
		#define LEDMASK_USB_ENUMERATING (LEDS_LED2 | LEDS_LED3)

		/** LED mask for the library LED driver, to indicate that the USB interface is ready. */
		#define LEDMASK_USB_READY       (LEDS_LED2 | LEDS_LED4)

		/** LED mask for the library LED driver, to indicate that an error has occurred in the USB interface. */
		#define LEDMASK_USB_ERROR       (LEDS_LED1 | LEDS_LED3)

	/* Function Prototypes: */
		extern void EVENT_USB_Device_Connect(void);
		extern void EVENT_USB_Device_Disconnect(void);
		extern void EVENT_USB_Device_ConfigurationChanged(void);
		extern void EVENT_USB_Device_ControlRequest(void);

#endif // __JXMAKE_USB_GPIO_H__
